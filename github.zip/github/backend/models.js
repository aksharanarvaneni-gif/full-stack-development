const mongoose = require("mongoose");

const studentSchema = new mongoose.Schema({
    studentId: Number,
    score: Number
});

module.exports = mongoose.model("Student", studentSchema);