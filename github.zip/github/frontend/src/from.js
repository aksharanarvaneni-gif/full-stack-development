import React, { useState } from "react";
import axios from "axios";

function Form() {
  const [studentId, setStudentId] = useState("");
  const [score, setScore] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    await axios.post("http://localhost:5000/api/students", {
      studentId,
      score
    });
    alert("Student added!");
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        type="number"
        placeholder="Student ID"
        onChange={(e) => setStudentId(e.target.value)}
      />
      <input
        type="number"
        placeholder="Score"
        onChange={(e) => setScore(e.target.value)}
      />
      <button type="submit">Add</button>
    </form>
  );
}

export default Form;