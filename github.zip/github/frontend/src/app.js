import React from "react";
import Form from "./components/Form";
import List from "./components/List";

function App() {
  return (
    <div>
      <h1>Student Score Manager</h1>
      <Form />
      <List />
    </div>
  );
}

export default App;