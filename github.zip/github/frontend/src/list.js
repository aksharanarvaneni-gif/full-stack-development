import React, { useEffect, useState } from "react";
import axios from "axios";

function List() {
  const [students, setStudents] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:5000/api/students")
      .then(res => setStudents(res.data));
  }, []);

  return (
    <div>
      <h2>Student List</h2>
      <ul>
        {students.map((s, index) => (
          <li key={index}>
            ID: {s.studentId} - Score: {s.score}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default List;